<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Savings_model extends MY_Model {
    
    public function __construct() {
        parent::__construct();
        $this->table = 'savings';
    }
    
    /**
     * Get all savings by user
     */
    public function get_by_user($user_id) {
        $this->db->where('user_id', $user_id);
        $this->db->order_by('deposit_date', 'DESC');
        return $this->db->get($this->table)->result();
    }
    
    /**
     * Get total savings by user for current month
     */
    public function get_total_by_user_month($user_id, $month, $year) {
        $this->db->select_sum('amount');
        $this->db->where('user_id', $user_id);
        $this->db->where('MONTH(deposit_date)', $month);
        $this->db->where('YEAR(deposit_date)', $year);
        $result = $this->db->get($this->table)->row();
        return $result->amount ?? 0;
    }
    
    /**
     * Get total savings by user (all time)
     */
    public function get_total_by_user($user_id) {
        $this->db->select_sum('amount');
        $this->db->where('user_id', $user_id);
        $result = $this->db->get($this->table)->row();
        return $result->amount ?? 0;
    }
    
    /**
     * Get savings by user for specific month
     */
    public function get_by_user_month($user_id, $month, $year) {
        $this->db->where('user_id', $user_id);
        $this->db->where('MONTH(deposit_date)', $month);
        $this->db->where('YEAR(deposit_date)', $year);
        $this->db->order_by('deposit_date', 'DESC');
        return $this->db->get($this->table)->result();
    }
}
