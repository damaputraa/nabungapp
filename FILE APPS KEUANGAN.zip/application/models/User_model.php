<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends MY_Model {
    public function __construct() {
        parent::__construct();
        $this->table = 'users';
    }
    
    public function get_by_username($username) {
        return $this->db->get_where($this->table, ['username' => $username])->row();
    }
    
    public function get_by_email($email) {
        return $this->db->get_where($this->table, ['email' => $email])->row();
    }
    
    // ========== TAMBAHKAN METHOD INI ==========
    public function get_user_by_id($id) {
        return $this->db->get_where($this->table, ['id' => $id])->row();
    }
    
    public function get_all_users() {
        $this->db->order_by('id', 'ASC');
        return $this->db->get($this->table)->result();
    }
}
