<div class="row">
	<div class="col-12">
		<div class="card card-primary">
			<div class="card-header">
				<h3 class="card-title">
					<i class="fas fa-list"></i> Daftar Transaksi
				</h3>
				<div class="card-tools">
					<a href="<?= site_url('transactions/add') ?>" class="btn btn-success btn-sm">
						<i class="fas fa-plus"></i> Tambah Transaksi
					</a>
				</div>
			</div>
			<div class="card-body">
				<?php if ($this->session->flashdata('success')): ?>
					<div class="alert alert-success alert-dismissible">
						<button type="button" class="close" data-dismiss="alert">&times;</button>
						<?= $this->session->flashdata('success') ?>
					</div>
				<?php endif; ?>

				<!-- Filter -->
				<div class="card card-info">
					<div class="card-header">
						<h3 class="card-title">
							<i class="fas fa-filter"></i> Filter Transaksi
						</h3>
					</div>
					<div class="card-body">
						<form method="GET" action="<?= site_url('transactions') ?>">
							<div class="row">
								<div class="col-md-3">
									<div class="form-group">
										<label>Jenis</label>
										<select name="type" class="form-control">
											<option value="">Semua</option>
											<option value="income" <?= $type == 'income' ? 'selected' : '' ?>>Pemasukan</option>
											<option value="expense" <?= $type == 'expense' ? 'selected' : '' ?>>Pengeluaran</option>
										</select>
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group">
										<label>Kategori</label>
										<select name="category" class="form-control">
											<option value="">Semua</option>
											<option value="Gaji" <?= $category == 'Gaji' ? 'selected' : '' ?>>Gaji</option>
											<option value="Makanan" <?= $category == 'Makanan' ? 'selected' : '' ?>>Makanan</option>
											<option value="Transportasi" <?= $category == 'Transportasi' ? 'selected' : '' ?>>Transportasi</option>
											<option value="Tagihan" <?= $category == 'Tagihan' ? 'selected' : '' ?>>Tagihan</option>
											<option value="Belanja" <?= $category == 'Belanja' ? 'selected' : '' ?>>Belanja</option>
											<option value="Hiburan" <?= $category == 'Hiburan' ? 'selected' : '' ?>>Hiburan</option>
											<option value="Kesehatan" <?= $category == 'Kesehatan' ? 'selected' : '' ?>>Kesehatan</option>
											<option value="Lainnya" <?= $category == 'Lainnya' ? 'selected' : '' ?>>Lainnya</option>
										</select>
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label>Dari Tanggal</label>
										<input type="date" name="date_from" class="form-control" value="<?= $date_from ?>">
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label>Sampai Tanggal</label>
										<input type="date" name="date_to" class="form-control" value="<?= $date_to ?>">
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label>&nbsp;</label>
										<button type="submit" class="btn btn-primary btn-block">
											<i class="fas fa-search"></i> Filter
										</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>

				<table id="table-transactions" class="table table-bordered table-hover">
					<thead>
						<tr>
							<th>Tanggal</th>
							<th>Jenis</th>
							<th>Kategori</th>
							<th>Jumlah</th>
							<th>Keterangan</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($transactions as $trx): ?>
							<tr>
								<td><?= date('d-m-Y', strtotime($trx->transaction_date)) ?></td>
								<td>
									<?php if ($trx->type == 'income'): ?>
										<span class="badge badge-success">Pemasukan</span>
									<?php else: ?>
										<span class="badge badge-danger">Pengeluaran</span>
									<?php endif; ?>
								</td>
								<td><?= $trx->category ?></td>
								<td>Rp <?= number_format($trx->amount, 0, ',', '.') ?></td>
								<td><?= $trx->description ?? '-' ?></td>
								<td>
									<a href="<?= site_url('transactions/edit/' . $trx->id) ?>" class="btn btn-warning btn-sm">
										<i class="fas fa-edit"></i>
									</a>
									<a href="<?= site_url('transactions/delete/' . $trx->id) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">
										<i class="fas fa-trash"></i>
									</a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
