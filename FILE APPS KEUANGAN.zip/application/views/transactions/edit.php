<div class="row">
    <div class="col-md-6">
        <div class="card card-warning">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-edit"></i> Edit Transaksi
                </h3>
            </div>
            <div class="card-body">
                <?php if (validation_errors()): ?>
                <div class="alert alert-danger">
                    <?= validation_errors() ?>
                </div>
                <?php endif; ?>

                <form action="<?= site_url('transactions/edit/' . $transaction->id) ?>" method="POST">
                    <div class="form-group">
                        <label>Jenis Transaksi</label>
                        <select name="type" class="form-control" required>
                            <option value="income" <?= $transaction->type == 'income' ? 'selected' : '' ?>>Pemasukan</option>
                            <option value="expense" <?= $transaction->type == 'expense' ? 'selected' : '' ?>>Pengeluaran</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Kategori</label>
                        <select name="category" class="form-control" required>
                            <option value="Gaji" <?= $transaction->category == 'Gaji' ? 'selected' : '' ?>>Gaji</option>
                            <option value="Bonus" <?= $transaction->category == 'Bonus' ? 'selected' : '' ?>>Bonus</option>
                            <option value="Investasi" <?= $transaction->category == 'Investasi' ? 'selected' : '' ?>>Investasi</option>
                            <option value="Makanan" <?= $transaction->category == 'Makanan' ? 'selected' : '' ?>>Makanan</option>
                            <option value="Transportasi" <?= $transaction->category == 'Transportasi' ? 'selected' : '' ?>>Transportasi</option>
                            <option value="Tagihan" <?= $transaction->category == 'Tagihan' ? 'selected' : '' ?>>Tagihan</option>
                            <option value="Belanja" <?= $transaction->category == 'Belanja' ? 'selected' : '' ?>>Belanja</option>
                            <option value="Hiburan" <?= $transaction->category == 'Hiburan' ? 'selected' : '' ?>>Hiburan</option>
                            <option value="Kesehatan" <?= $transaction->category == 'Kesehatan' ? 'selected' : '' ?>>Kesehatan</option>
                            <option value="Lainnya" <?= $transaction->category == 'Lainnya' ? 'selected' : '' ?>>Lainnya</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Jumlah (Rp)</label>
                        <input type="number" name="amount" class="form-control" value="<?= $transaction->amount ?>" required min="0">
                    </div>
                    <div class="form-group">
                        <label>Tanggal</label>
                        <input type="date" name="transaction_date" class="form-control" value="<?= $transaction->transaction_date ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Keterangan</label>
                        <textarea name="description" class="form-control"><?= $transaction->description ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-save"></i> Update
                    </button>
                    <a href="<?= site_url('transactions') ?>" class="btn btn-default">Batal</a>
                </form>
            </div>
        </div>
    </div>
</div>
