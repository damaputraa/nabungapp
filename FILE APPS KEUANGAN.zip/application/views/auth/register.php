<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register - Keuangan DAMS</title>
    <!-- Bootstrap 5 + AdminLTE 4 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@4.0.0/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #00a651, #00c853);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 20px;
        }
        .register-card {
            background: white;
            border-radius: 24px;
            padding: 35px 30px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
            max-width: 440px;
            width: 100%;
            animation: fadeInUp 0.6s ease;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .register-card .brand {
            text-align: center;
            margin-bottom: 25px;
        }
        .register-card .brand i {
            font-size: 40px;
            color: #00a651;
            background: #e8f5e9;
            padding: 12px;
            border-radius: 50%;
        }
        .register-card .brand h3 {
            font-weight: 700;
            color: #1a1a2e;
            margin-top: 10px;
        }
        .register-card .brand p {
            color: #888;
            font-size: 14px;
        }
        .btn-primary {
            background: linear-gradient(135deg, #00a651, #00c853);
            border: none;
            transition: all 0.3s ease;
            padding: 12px;
            font-weight: 600;
            border-radius: 30px;
            width: 100%;
        }
        .btn-primary:hover {
            transform: scale(1.02);
            box-shadow: 0 5px 20px rgba(0, 166, 81, 0.4);
        }
        .form-control {
            border-radius: 12px;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #00a651;
            box-shadow: 0 0 0 4px rgba(0, 166, 81, 0.1);
        }
        .form-label {
            font-weight: 600;
            color: #1a1a2e;
            font-size: 14px;
        }
        .alert {
            border-radius: 12px;
        }
        .login-link {
            color: #00a651;
            font-weight: 600;
            text-decoration: none;
        }
        .login-link:hover {
            text-decoration: underline;
        }
        .password-hint {
            font-size: 12px;
            color: #999;
            margin-top: 4px;
        }
    </style>
</head>
<body>
    <div class="register-card">
        <div class="brand">
            <i class="fas fa-user-plus"></i>
            <h3>Daftar Akun</h3>
            <p>Buat akun untuk mulai menabung</p>
        </div>

        <?php if (validation_errors()): ?>
        <div class="alert alert-danger">
            <?= validation_errors() ?>
        </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $this->session->flashdata('error') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $this->session->flashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <form action="<?= site_url('auth/register') ?>" method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" name="username" class="form-control" id="username" placeholder="Masukkan username" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" class="form-control" id="email" placeholder="Masukkan email" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="password" placeholder="Minimal 6 karakter" required minlength="6">
                <div class="password-hint">Minimal 6 karakter</div>
            </div>
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                <input type="password" name="confirm_password" class="form-control" id="confirm_password" placeholder="Ulangi password" required>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-user-plus"></i> Daftar
            </button>
        </form>

        <div class="text-center mt-3">
            <p class="text-muted">
                Sudah punya akun? 
                <a href="<?= site_url('auth/login') ?>" class="login-link">
                    Login di sini
                </a>
            </p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
