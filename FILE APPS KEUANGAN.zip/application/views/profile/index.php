<div class="row">
    <div class="col-md-6">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-user"></i> Data Profile
                </h3>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <th>Username</th>
                        <td><?= $user->username ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?= $user->email ?></td>
                    </tr>
                    <tr>
                        <th>Role</th>
                        <td><span class="badge badge-<?= $user->role == 'admin' ? 'danger' : 'info' ?>">
                            <?= ucfirst($user->role) ?>
                        </span></td>
                    </tr>
                    <tr>
                        <th>Bergabung</th>
                        <td><?= date('d-m-Y', strtotime($user->created_at)) ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card card-warning">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-key"></i> Ubah Password
                </h3>
            </div>
            <div class="card-body">
                <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success"><?= $this->session->flashdata('success') ?></div>
                <?php endif; ?>
                
                <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger"><?= $this->session->flashdata('error') ?></div>
                <?php endif; ?>
                
                <?php if (validation_errors()): ?>
                <div class="alert alert-danger"><?= validation_errors() ?></div>
                <?php endif; ?>
                
                <form action="<?= site_url('profile/update_password') ?>" method="POST">
                    <div class="form-group">
                        <label>Password Lama</label>
                        <input type="password" name="old_password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Password Baru</label>
                        <input type="password" name="new_password" class="form-control" required minlength="6">
                        <small class="text-muted">Minimal 6 karakter</small>
                    </div>
                    <div class="form-group">
                        <label>Konfirmasi Password Baru</label>
                        <input type="password" name="confirm_password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-save"></i> Update Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
