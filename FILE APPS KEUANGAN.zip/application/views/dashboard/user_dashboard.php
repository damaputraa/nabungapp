<?php
$user_name = $this->session->userdata('username') ?? 'User';
$role = $this->session->userdata('role') ?? 'user';
$is_admin = ($role == 'admin');
?>

<!-- ======================================== -->
<!-- MOBILE APP STYLE DASHBOARD - USER VERSION -->
<!-- ======================================== -->

<style>
/* ======================================== */
/* GAYA MOBILE APPS ALA GOJEK */
/* ======================================== */

:root {
    --primary: #00a651;
    --primary-dark: #008a45;
    --primary-light: #e8f5e9;
    --primary-gradient: linear-gradient(135deg, #00a651, #00c853);
    --shadow-light: 0 4px 20px rgba(0, 166, 81, 0.15);
    --shadow-card: 0 2px 15px rgba(0, 0, 0, 0.06);
    --radius-card: 20px;
    --radius-sm: 12px;
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

/* Reset untuk tampilan mobile */
.user-dashboard {
    padding: 0 !important;
    margin: 0 !important;
    background: #f5f7fa;
    min-height: 100vh;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

/* ======================================== */
/* HEADER DENGAN GREETING */
/* ======================================== */
.dashboard-header {
    background: var(--primary-gradient);
    padding: 25px 20px 40px 20px;
    border-radius: 0 0 30px 30px;
    color: #fff;
    position: relative;
    overflow: hidden;
}

.dashboard-header::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 200px;
    height: 200px;
    background: rgba(255, 255, 255, 0.08);
    border-radius: 50%;
}

.dashboard-header .greeting {
    font-size: 14px;
    opacity: 0.85;
    margin-bottom: 2px;
}

.dashboard-header .username {
    font-size: 22px;
    font-weight: 700;
    margin-bottom: 5px;
}

.dashboard-header .date {
    font-size: 13px;
    opacity: 0.8;
}

/* ======================================== */
/* CARD SALDO UTAMA */
/* ======================================== */
.saldo-card {
    background: #fff;
    margin: -25px 15px 20px 15px;
    border-radius: var(--radius-card);
    padding: 20px 25px;
    box-shadow: var(--shadow-light);
    position: relative;
    z-index: 10;
    border: none;
}

.saldo-card .saldo-label {
    font-size: 13px;
    color: #888;
    font-weight: 500;
}

.saldo-card .saldo-amount {
    font-size: 28px;
    font-weight: 800;
    color: #1a1a2e;
    margin: 5px 0;
}

.saldo-card .saldo-detail {
    display: flex;
    gap: 20px;
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid #f0f0f0;
}

.saldo-card .saldo-detail .item {
    flex: 1;
}

.saldo-card .saldo-detail .item .label {
    font-size: 11px;
    color: #999;
}

.saldo-card .saldo-detail .item .value {
    font-size: 15px;
    font-weight: 600;
}

.saldo-card .saldo-detail .item .value.income {
    color: #00a651;
}

.saldo-card .saldo-detail .item .value.expense {
    color: #e74c3c;
}

/* ======================================== */
/* QUICK ACTION BUTTONS */
/* ======================================== */
.quick-actions {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    padding: 0 15px;
    margin-bottom: 20px;
}

.quick-actions .action-btn {
    background: #fff;
    border: none;
    border-radius: var(--radius-sm);
    padding: 15px 10px;
    text-align: center;
    box-shadow: var(--shadow-card);
    transition: var(--transition);
    cursor: pointer;
    text-decoration: none;
    color: #333;
}

.quick-actions .action-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 25px rgba(0, 0, 0, 0.08);
}

.quick-actions .action-btn .icon {
    font-size: 28px;
    display: block;
    margin-bottom: 5px;
}

.quick-actions .action-btn .label {
    font-size: 12px;
    font-weight: 500;
    color: #555;
}

.quick-actions .action-btn .icon.income { color: #00a651; }
.quick-actions .action-btn .icon.expense { color: #e74c3c; }
.quick-actions .action-btn .icon.saving { color: #f39c12; }
.quick-actions .action-btn .icon.report { color: #3498db; }

/* ======================================== */
/* PROGRESS CARD */
/* ======================================== */
.progress-card {
    background: #fff;
    margin: 0 15px 15px 15px;
    border-radius: var(--radius-card);
    padding: 18px 20px;
    box-shadow: var(--shadow-card);
    border: none;
}

.progress-card .progress-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.progress-card .progress-header .title {
    font-size: 14px;
    font-weight: 600;
    color: #1a1a2e;
}

.progress-card .progress-header .target-amount {
    font-size: 13px;
    font-weight: 700;
    color: var(--primary);
}

.progress-card .progress-bar-custom {
    height: 12px;
    background: #e9ecef;
    border-radius: 10px;
    overflow: hidden;
    margin: 8px 0;
}

.progress-card .progress-bar-custom .fill {
    height: 100%;
    background: var(--primary-gradient);
    border-radius: 10px;
    transition: width 1s ease;
    position: relative;
}

.progress-card .progress-bar-custom .fill::after {
    content: '';
    position: absolute;
    right: -4px;
    top: -2px;
    width: 16px;
    height: 16px;
    background: #00a651;
    border-radius: 50%;
    box-shadow: 0 0 10px rgba(0, 166, 81, 0.3);
}

.progress-card .progress-stats {
    display: flex;
    justify-content: space-between;
    font-size: 12px;
    color: #888;
    margin-top: 5px;
}

.progress-card .progress-stats .current {
    font-weight: 600;
    color: #1a1a2e;
}

.progress-card .progress-stats .remaining {
    font-weight: 600;
    color: #e74c3c;
}

/* ======================================== */
/* RECENT TRANSACTIONS */
/* ======================================== */
.transaction-card {
    background: #fff;
    margin: 0 15px 15px 15px;
    border-radius: var(--radius-card);
    padding: 18px 20px;
    box-shadow: var(--shadow-card);
    border: none;
}

.transaction-card .card-header-custom {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}

.transaction-card .card-header-custom .title {
    font-size: 14px;
    font-weight: 600;
    color: #1a1a2e;
}

.transaction-card .card-header-custom .see-all {
    font-size: 12px;
    color: var(--primary);
    text-decoration: none;
    font-weight: 500;
}

.transaction-item {
    display: flex;
    align-items: center;
    padding: 10px 0;
    border-bottom: 1px solid #f5f5f5;
    transition: var(--transition);
}

.transaction-item:last-child {
    border-bottom: none;
}

.transaction-item .icon-circle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    margin-right: 12px;
    flex-shrink: 0;
}

.transaction-item .icon-circle.income {
    background: #e8f5e9;
    color: #00a651;
}

.transaction-item .icon-circle.expense {
    background: #fde8e8;
    color: #e74c3c;
}

.transaction-item .info {
    flex: 1;
}

.transaction-item .info .name {
    font-size: 14px;
    font-weight: 500;
    color: #1a1a2e;
}

.transaction-item .info .date {
    font-size: 11px;
    color: #999;
}

.transaction-item .amount {
    font-size: 14px;
    font-weight: 600;
}

.transaction-item .amount.income {
    color: #00a651;
}

.transaction-item .amount.expense {
    color: #e74c3c;
}

/* ======================================== */
/* HELP CARD */
/* ======================================== */
.help-card {
    background: var(--primary-gradient);
    margin: 0 15px 20px 15px;
    border-radius: var(--radius-card);
    padding: 18px 20px;
    color: #fff;
    border: none;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.help-card .help-text {
    font-size: 13px;
    font-weight: 500;
}

.help-card .help-text small {
    display: block;
    font-weight: 300;
    opacity: 0.8;
    font-size: 12px;
    margin-top: 3px;
}

.help-card .help-btn {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    border-radius: 30px;
    padding: 8px 18px;
    color: #fff;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: var(--transition);
}

.help-card .help-btn:hover {
    background: rgba(255, 255, 255, 0.35);
}

/* ======================================== */
/* BOTTOM NAVIGATION (Mobile) */
/* ======================================== */
.bottom-nav {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: #fff;
    display: flex;
    justify-content: space-around;
    padding: 8px 0 12px 0;
    box-shadow: 0 -2px 15px rgba(0, 0, 0, 0.06);
    z-index: 1000;
    border-radius: 20px 20px 0 0;
}

.bottom-nav .nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-decoration: none;
    color: #999;
    font-size: 10px;
    transition: var(--transition);
    padding: 4px 12px;
    border: none;
    background: none;
    cursor: pointer;
}

.bottom-nav .nav-item .nav-icon {
    font-size: 22px;
    margin-bottom: 2px;
    transition: var(--transition);
}

.bottom-nav .nav-item.active {
    color: var(--primary);
}

.bottom-nav .nav-item.active .nav-icon {
    transform: translateY(-2px);
}

.bottom-nav .nav-item .badge-nav {
    background: #e74c3c;
    color: #fff;
    font-size: 9px;
    border-radius: 50%;
    padding: 1px 6px;
    position: absolute;
    top: -4px;
    right: -8px;
}

.bottom-nav .nav-item .nav-icon-wrapper {
    position: relative;
}

/* ======================================== */
/* EMPTY STATE */
/* ======================================== */
.empty-state {
    text-align: center;
    padding: 30px 20px;
}

.empty-state .icon {
    font-size: 48px;
    color: #ccc;
    margin-bottom: 15px;
}

.empty-state .title {
    font-size: 16px;
    font-weight: 600;
    color: #1a1a2e;
}

.empty-state .subtitle {
    font-size: 13px;
    color: #999;
}

/* ======================================== */
/* RESPONSIVE UNTUK TABLET & DESKTOP */
/* ======================================== */
@media (min-width: 768px) {
    .user-dashboard {
        padding: 0 40px !important;
    }
    
    .quick-actions {
        grid-template-columns: repeat(4, 1fr);
        gap: 15px;
    }
    
    .bottom-nav {
        display: none !important;
    }
    
    .dashboard-header {
        border-radius: 0 0 40px 40px;
        padding: 35px 40px 50px 40px;
    }
    
    .saldo-card {
        margin: -30px 30px 25px 30px;
        padding: 25px 30px;
    }
    
    .progress-card,
    .transaction-card,
    .help-card {
        margin: 0 30px 20px 30px;
    }
    
    .saldo-card .saldo-amount {
        font-size: 36px;
    }
}

@media (min-width: 1024px) {
    .user-dashboard {
        padding: 0 60px !important;
        max-width: 1200px;
        margin: 0 auto;
    }
}

/* ======================================== */
/* ANIMASI MASUK */
/* ======================================== */
@keyframes slideUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.dashboard-header { animation: slideUp 0.5s ease; }
.saldo-card { animation: slideUp 0.6s ease; }
.quick-actions { animation: slideUp 0.7s ease; }
.progress-card { animation: slideUp 0.8s ease; }
.transaction-card { animation: slideUp 0.9s ease; }
.help-card { animation: slideUp 1s ease; }
</style>

<!-- ======================================== -->
<!-- KONTEN DASHBOARD MOBILE -->
<!-- ======================================== -->

<div class="user-dashboard">

    <!-- ========== HEADER ========== -->
    <div class="dashboard-header">
        <div class="greeting">Hai,</div>
        <div class="username"><?= $user_name ?>! 👋</div>
        <div class="date"><?= date('l, d F Y') ?></div>
    </div>

    <!-- ========== CARD SALDO ========== -->
    <div class="saldo-card">
        <div class="saldo-label">💳 Total Saldo</div>
        <div class="saldo-amount">Rp <?= number_format($balance ?? 0, 0, ',', '.') ?></div>
        <div class="saldo-detail">
            <div class="item">
                <div class="label">Pemasukan</div>
                <div class="value income">+ Rp <?= number_format($total_income ?? 0, 0, ',', '.') ?></div>
            </div>
            <div class="item">
                <div class="label">Pengeluaran</div>
                <div class="value expense">- Rp <?= number_format($total_expense ?? 0, 0, ',', '.') ?></div>
            </div>
        </div>
    </div>

    <!-- ========== QUICK ACTIONS ========== -->
    <div class="quick-actions">
        <a href="<?= site_url('transactions/add') ?>" class="action-btn">
            <span class="icon income">💰</span>
            <span class="label">Kas Masuk</span>
        </a>
        <a href="<?= site_url('transactions/add') ?>" class="action-btn">
            <span class="icon expense">💸</span>
            <span class="label">Kas Keluar</span>
        </a>
        <a href="<?= site_url('savings/add') ?>" class="action-btn">
            <span class="icon saving">🏦</span>
            <span class="label">Tabungan</span>
        </a>
		<a href="<?= site_url('savings/leaderboard') ?>" class="action-btn">
        <span class="icon report">🏆</span>
        <span class="label">Leaderboard</span>
    	</a>
        <?php if ($is_admin): ?>
        <a href="<?= site_url('admin/targets') ?>" class="action-btn">
            <span class="icon report">🎯</span>
            <span class="label">Target</span>
        </a>
        <?php else: ?>
        <a href="<?= site_url('transactions') ?>" class="action-btn">
            <span class="icon report">📊</span>
            <span class="label">Riwayat</span>
        </a>
        <?php endif; ?>
    </div>

    <!-- ========== PROGRESS TABUNGAN ========== -->
    <?php 
    $target_amount = isset($savings_target) && $savings_target ? (float) $savings_target->target_amount : 1;
    $current_saving = (float) ($savings_total_deposit ?? 0);
    $percentage = $target_amount > 0 ? min(($current_saving / $target_amount) * 100, 100) : 0;
    $remaining = max(0, $target_amount - $current_saving);
    ?>
    
    <div class="progress-card">
        <div class="progress-header">
            <span class="title">📈 Progress Tabungan</span>
            <span class="target-amount">🎯 Rp <?= number_format($target_amount, 0, ',', '.') ?></span>
        </div>
        <div class="progress-bar-custom">
            <div class="fill" style="width: <?= $percentage ?>%;"></div>
        </div>
        <div class="progress-stats">
            <span class="current">Rp <?= number_format($current_saving, 0, ',', '.') ?></span>
            <span class="remaining">Sisa: Rp <?= number_format($remaining, 0, ',', '.') ?></span>
        </div>
        <div style="text-align: center; margin-top: 8px; font-size: 13px; font-weight: 600; color: var(--primary);">
            <?= round($percentage, 1) ?>% Tercapai
        </div>
    </div>

    <!-- ========== TRANSAKSI TERAKHIR ========== -->
    <?php 
    $recent_transactions = array_slice($transactions ?? [], 0, 3);
    ?>
    
    <div class="transaction-card">
        <div class="card-header-custom">
            <span class="title">🕐 Transaksi Terakhir</span>
            <a href="<?= site_url('transactions') ?>" class="see-all">Lihat Semua →</a>
        </div>
        
        <?php if (empty($recent_transactions)): ?>
        <div class="empty-state">
            <div class="icon">📭</div>
            <div class="title">Belum ada transaksi</div>
            <div class="subtitle">Mulai catat pengeluaranmu sekarang</div>
        </div>
        <?php else: ?>
        <?php foreach ($recent_transactions as $trx): ?>
        <div class="transaction-item">
            <div class="icon-circle <?= $trx->type ?>">
                <i class="fas fa-<?= $trx->type == 'income' ? 'arrow-down' : 'arrow-up' ?>"></i>
            </div>
            <div class="info">
                <div class="name"><?= $trx->category ?? 'Transaksi' ?></div>
                <div class="date"><?= date('d M Y', strtotime($trx->transaction_date ?? date('Y-m-d'))) ?></div>
            </div>
            <div class="amount <?= $trx->type ?>">
                <?= $trx->type == 'income' ? '+' : '-' ?> Rp <?= number_format($trx->amount ?? 0, 0, ',', '.') ?>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- ========== HELP CARD ========== -->
    <div class="help-card">
        <div class="help-text">
            💬 Butuh Bantuan?
            <small>Hubungi admin jika ada masalah</small>
        </div>
        <button class="help-btn" onclick="alert('Hubungi admin via email: admin@keuangandams.com')">
            Hubungi
        </button>
    </div>

    <!-- ========== BOTTOM NAVIGATION ========== -->
    <!-- <div class="bottom-nav">
        <a href="<?= site_url('dashboard') ?>" class="nav-item active">
            <span class="nav-icon-wrapper">
                <i class="fas fa-home nav-icon"></i>
            </span>
            <span>Beranda</span>
        </a>
        <a href="<?= site_url('transactions') ?>" class="nav-item">
            <span class="nav-icon-wrapper">
                <i class="fas fa-exchange-alt nav-icon"></i>
            </span>
            <span>Transaksi</span>
        </a>
        <a href="<?= site_url('savings') ?>" class="nav-item">
            <span class="nav-icon-wrapper">
                <i class="fas fa-piggy-bank nav-icon"></i>
            </span>
            <span>Tabungan</span>
        </a>
        <a href="<?= site_url('profile') ?>" class="nav-item">
            <span class="nav-icon-wrapper">
                <i class="fas fa-user nav-icon"></i>
            </span>
            <span>Profil</span>
        </a>
        <?php if ($is_admin): ?>
        <a href="<?= site_url('admin/users') ?>" class="nav-item">
            <span class="nav-icon-wrapper">
                <i class="fas fa-cog nav-icon"></i>
            </span>
            <span>Admin</span>
        </a>
        <?php endif; ?>
    </div> -->

</div>
