<!-- Notifikasi -->
<?php if (isset($notification) && !empty($notification)): ?>
<div class="row">
    <div class="col-12">
        <div class="alert alert-<?= $notification['type'] ?? 'info' ?> alert-dismissible fade show">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <i class="fas fa-bell mr-2"></i> <?= $notification['message'] ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Statistik -->
<div class="row">
    <div class="col-lg-3 col-6">
        <div class="small-box bg-primary">
            <div class="inner">
                <h3>Rp <?= number_format($total_income ?? 0, 0, ',', '.') ?></h3>
                <p>Total Pemasukan</p>
            </div>
            <div class="icon">
                <i class="fas fa-arrow-down"></i>
            </div>
            <a href="<?= site_url('transactions?type=income') ?>" class="small-box-footer">
                Lihat Detail <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    
    <div class="col-lg-3 col-6">
        <div class="small-box bg-danger">
            <div class="inner">
                <h3>Rp <?= number_format($total_expense ?? 0, 0, ',', '.') ?></h3>
                <p>Total Pengeluaran</p>
            </div>
            <div class="icon">
                <i class="fas fa-arrow-up"></i>
            </div>
            <a href="<?= site_url('transactions?type=expense') ?>" class="small-box-footer">
                Lihat Detail <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    
    <div class="col-lg-3 col-6">
        <div class="small-box bg-success">
            <div class="inner">
                <h3>Rp <?= number_format($balance ?? 0, 0, ',', '.') ?></h3>
                <p>Saldo</p>
            </div>
            <div class="icon">
                <i class="fas fa-wallet"></i>
            </div>
        </div>
    </div>
    
    <div class="col-lg-3 col-6">
        <div class="small-box bg-warning">
            <div class="inner">
                <h3><?= isset($savings_target) && $savings_target ? 'Rp ' . number_format($savings_target->target_amount ?? 0, 0, ',', '.') : 'Belum diset' ?></h3>
                <p>Target Tabungan</p>
            </div>
            <div class="icon">
                <i class="fas fa-piggy-bank"></i>
            </div>
            <a href="<?= site_url('savings') ?>" class="small-box-footer">
                Lihat Detail <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
</div>

<!-- Grafik -->
<div class="row">
    <div class="col-md-6">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-chart-pie"></i> Grafik Pemasukan vs Pengeluaran
                </h3>
            </div>
            <div class="card-body" style="min-height: 280px;">
                <canvas id="chartIncomeExpense" 
                        style="height: 250px; width: 100%;"
                        data-income="<?= (int) ($total_income ?? 0) ?>"
                        data-expense="<?= (int) ($total_expense ?? 0) ?>">
                </canvas>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card card-success">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-chart-bar"></i> Grafik Tabungan
                </h3>
            </div>
            <div class="card-body" style="min-height: 280px;">
                <canvas id="chartSavings"
                        style="height: 250px; width: 100%;"
                        data-target="<?= (int) ($savings_target->target_amount ?? 0) ?>"
                        data-deposit="<?= (int) ($savings_total_deposit ?? 0) ?>">
                </canvas>
            </div>
        </div>
    </div>
</div>

<!-- Progress Tabungan -->
<div class="row">
    <div class="col-md-6">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-piggy-bank"></i> Progress Tabungan Bulan Ini
                </h3>
            </div>
            <div class="card-body">
                <?php 
                $target_amount = isset($savings_target) && $savings_target ? (float) $savings_target->target_amount : 1;
                $current_saving = (float) ($savings_total_deposit ?? 0);
                $percentage = $target_amount > 0 ? min(($current_saving / $target_amount) * 100, 100) : 0;
                ?>
                <div class="d-flex justify-content-between mb-1">
                    <span><strong>Rp <?= number_format($current_saving, 0, ',', '.') ?></strong></span>
                    <span><strong>Target: Rp <?= number_format($target_amount, 0, ',', '.') ?></strong></span>
                </div>
                <div class="progress" style="height: 30px;">
                    <div class="progress-bar bg-primary progress-bar-striped progress-bar-animated" 
                         role="progressbar" 
                         style="width: <?= $percentage ?>%;" 
                         aria-valuenow="<?= $percentage ?>" 
                         aria-valuemin="0" 
                         aria-valuemax="100">
                        <?= round($percentage, 1) ?>%
                    </div>
                </div>
                <div class="mt-2 text-center text-muted small">
                    <?php if ($percentage < 100): ?>
                        Sisa target: Rp <?= number_format(max(0, $target_amount - $current_saving), 0, ',', '.') ?>
                    <?php else: ?>
                        🎉 Selamat! Target tercapai!
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Ringkasan Tabungan Semua User (untuk admin) -->
<?php if ($this->session->userdata('role') == 'admin' && isset($all_users_savings) && !empty($all_users_savings)): ?>
<div class="row">
    <div class="col-12">
        <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-users"></i> Ringkasan Tabungan Semua User
                </h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Target Bulan Ini</th>
                                <th>Setoran Saat Ini</th>
                                <th>Progress</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($all_users_savings as $user): ?>
                            <tr>
                                <td><strong><?= $user->username ?></strong></td>
                                <td>Rp <?= number_format($user->target_amount ?? 0, 0, ',', '.') ?></td>
                                <td>Rp <?= number_format($user->total_deposit ?? 0, 0, ',', '.') ?></td>
                                <td style="min-width: 150px;">
                                    <?php 
                                    $progress = ($user->target_amount ?? 1) > 0 
                                        ? min(($user->total_deposit ?? 0) / ($user->target_amount ?? 1) * 100, 100) 
                                        : 0;
                                    ?>
                                    <div class="progress" style="height: 20px;">
                                        <div class="progress-bar bg-<?= $progress >= 100 ? 'success' : 'primary' ?>" 
                                             style="width: <?= $progress ?>%;">
                                            <?= round($progress, 1) ?>%
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
