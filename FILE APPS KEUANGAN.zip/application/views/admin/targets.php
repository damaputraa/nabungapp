<div class="row">
    <div class="col-12">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-bullseye"></i> Target Tabungan Bulan Ini
                </h3>
            </div>
            <div class="card-body">
                <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?= $this->session->flashdata('success') ?>
                </div>
                <?php endif; ?>

                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Target Bulan Ini</th>
                            <th>Tabungan Saat Ini</th>
                            <th>Progress</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= $user->username ?></td>
                            <td>
                                Rp <?= isset($user->target) ? number_format($user->target->target_amount, 0, ',', '.') : '0' ?>
                            </td>
                            <td>
                                Rp <?= isset($user->saving) ? number_format($user->saving->balance ?? 0, 0, ',', '.') : '0' ?>
                            </td>
                            <td>
                                <?php 
                                $target = isset($user->target) ? $user->target->target_amount : 1;
                                $saving = isset($user->saving) ? ($user->saving->balance ?? 0) : 0;
                                $progress = $target > 0 ? min(($saving / $target) * 100, 100) : 0;
                                ?>
                                <div class="progress" style="height: 20px;">
                                    <div class="progress-bar bg-primary" style="width: <?= $progress ?>%;">
                                        <?= round($progress, 1) ?>%
                                    </div>
                                </div>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modalTarget<?= $user->id ?>">
                                    <i class="fas fa-edit"></i> Set Target
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal untuk setiap user -->
<?php foreach ($users as $user): ?>
<div class="modal fade" id="modalTarget<?= $user->id ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Set Target Tabungan - <?= $user->username ?></h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form action="<?= site_url('admin/set_target') ?>" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="user_id" value="<?= $user->id ?>">
                    <div class="form-group">
                        <label>Target Bulan Ini (Rp)</label>
                        <input type="number" name="target_amount" class="form-control" 
                               value="<?= isset($user->target) ? $user->target->target_amount : '' ?>" 
                               placeholder="Masukkan target" required min="0">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Target</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>
