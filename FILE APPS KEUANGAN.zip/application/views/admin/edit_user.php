<div class="row">
    <div class="col-md-6">
        <div class="card card-warning">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-user-edit"></i> Edit User
                </h3>
            </div>
            <div class="card-body">
                <?php if (validation_errors()): ?>
                <div class="alert alert-danger">
                    <?= validation_errors() ?>
                </div>
                <?php endif; ?>

                <form action="<?= site_url('admin/edit_user/' . $user->id) ?>" method="POST">
                    <div class="form-group">
                        <label>Username <span class="text-danger">*</span></label>
                        <input type="text" name="username" class="form-control" 
                               value="<?= $user->username ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Email <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control" 
                               value="<?= $user->email ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" 
                               placeholder="Kosongkan jika tidak diubah" minlength="6">
                        <small class="text-muted">Minimal 6 karakter. Kosongkan jika tidak ingin mengganti password.</small>
                    </div>
                    <div class="form-group">
                        <label>Role <span class="text-danger">*</span></label>
                        <select name="role" class="form-control" required>
                            <option value="user" <?= $user->role == 'user' ? 'selected' : '' ?>>User</option>
                            <option value="admin" <?= $user->role == 'admin' ? 'selected' : '' ?>>Admin</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-save"></i> Update
                    </button>
                    <a href="<?= site_url('admin/users') ?>" class="btn btn-default">Batal</a>
                </form>
            </div>
        </div>
    </div>
</div>
