<!-- ================================================================ -->
<!-- NAVBAR -->
<!-- ================================================================ -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <?php if ($this->session->userdata('role') == 'admin'): ?>
        <!-- Tombol hamburger untuk admin -->
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button">
                <i class="fas fa-bars"></i>
            </a>
        </li>
        <?php else: ?>
        <!-- Logo untuk user -->
        <li class="nav-item">
            <span class="nav-link" style="font-weight: 700; color: #00a651; font-size: 16px;">
                <i class="fas fa-wallet"></i> Yuk Nabung
            </span>
        </li>
        <?php endif; ?>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="fas fa-user-circle"></i> <?= $this->session->userdata('username') ?? 'Guest' ?>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <a href="<?= site_url('profile') ?>" class="dropdown-item">
                    <i class="fas fa-user-cog"></i> Profil
                </a>
                <div class="dropdown-divider"></div>
                <a href="<?= site_url('auth/logout') ?>" class="dropdown-item text-danger">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </li>
    </ul>
</nav>

<!-- ================================================================ -->
<!-- SIDEBAR - HANYA UNTUK ADMIN -->
<!-- ================================================================ -->
<?php if ($this->session->userdata('role') == 'admin'): ?>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?= site_url('dashboard') ?>" class="brand-link">
        <span class="brand-text font-weight-light">
            <i class="fas fa-wallet" style="color: #60a5fa;"></i> Yuk Nabung
        </span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- User Panel -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <i class="fas fa-user-circle fa-2x" style="color: #60a5fa;"></i>
            </div>
            <div class="info">
                <a href="#" class="d-block"><?= $this->session->userdata('username') ?? 'User' ?></a>
                <span class="text-white-50 small"><?= ucfirst($this->session->userdata('role') ?? '') ?></span>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                <!-- ==================== -->
                <!-- MENU UTAMA -->
                <!-- ==================== -->
                <li class="nav-item">
                    <a href="<?= site_url('dashboard') ?>" class="nav-link <?= $this->uri->segment(1) == 'dashboard' ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="<?= site_url('transactions') ?>" class="nav-link <?= $this->uri->segment(1) == 'transactions' ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-exchange-alt"></i>
                        <p>Transaksi</p>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="<?= site_url('savings') ?>" class="nav-link <?= $this->uri->segment(1) == 'savings' ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-piggy-bank"></i>
                        <p>Tabungan</p>
                    </a>
                </li>

                <!-- ==================== -->
                <!-- MENU PROFIL -->
                <!-- ==================== -->
                <li class="nav-item">
                    <a href="<?= site_url('profile') ?>" class="nav-link <?= $this->uri->segment(1) == 'profile' ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-user-cog"></i>
                        <p>Profil & Password</p>
                    </a>
                </li>

                <!-- ==================== -->
                <!-- MENU ADMIN -->
                <!-- ==================== -->
                <li class="nav-header">ADMIN</li>
                
                <li class="nav-item">
                    <a href="<?= site_url('admin/users') ?>" class="nav-link <?= $this->uri->segment(2) == 'users' ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-users"></i>
                        <p>Kelola User</p>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="<?= site_url('admin/targets') ?>" class="nav-link <?= $this->uri->segment(2) == 'targets' ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-bullseye"></i>
                        <p>Target Tabungan</p>
                    </a>
                </li>

				<li class="nav-item">
					<a href="<?= site_url('savings/leaderboard') ?>" class="nav-link <?= $this->uri->segment(2) == 'leaderboard' ? 'active' : '' ?>">
						<i class="nav-icon fas fa-trophy"></i>
						<p>Leaderboard</p>
					</a>
				</li>
                
                <li class="nav-item">
                    <a href="<?= site_url('laporan') ?>" class="nav-link <?= $this->uri->segment(1) == 'laporan' ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-file-pdf"></i>
                        <p>Laporan PDF</p>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="<?= site_url('export') ?>" class="nav-link <?= $this->uri->segment(1) == 'export' ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-file-excel"></i>
                        <p>Export Excel</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<?php endif; ?>

<!-- ================================================================ -->
<!-- CONTENT WRAPPER -->
<!-- ================================================================ -->
<div class="content-wrapper <?= $this->session->userdata('role') == 'user' ? 'content-wrapper-full' : '' ?>">
