<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yuk Nabung - Kelola Keuangan & Tabungan</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    
    <!-- Google Font: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <style>
        /* ================================================================ */
        /* RESET & VARIABLES */
        /* ================================================================ */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        :root {
            --primary: #00a651;
            --primary-dark: #008a45;
            --primary-light: #e8f5e9;
            --secondary: #6c5ce7;
            --accent-1: #fd79a8;
            --accent-2: #fdcb6e;
            --accent-3: #74b9ff;
            --dark: #1a1a2e;
            --gray: #6c7a89;
            --light: #f8f9fa;
            --white: #ffffff;
            --shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            --shadow-hover: 0 20px 60px rgba(0, 0, 0, 0.12);
            --radius: 20px;
            --transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        html {
            scroll-behavior: smooth;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f8f9fa;
            color: var(--dark);
            overflow-x: hidden;
        }
        
        /* ================================================================ */
        /* ANIMATIONS */
        /* ================================================================ */
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(40px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes fadeInLeft {
            from {
                opacity: 0;
                transform: translateX(-60px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes fadeInRight {
            from {
                opacity: 0;
                transform: translateX(60px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fadeUp {
            animation: fadeInUp 0.8s ease forwards;
        }
        
        .animate-fadeLeft {
            animation: fadeInLeft 0.8s ease forwards;
        }
        
        .animate-fadeRight {
            animation: fadeInRight 0.8s ease forwards;
        }
        
        .delay-1 { animation-delay: 0.1s; }
        .delay-2 { animation-delay: 0.2s; }
        .delay-3 { animation-delay: 0.3s; }
        .delay-4 { animation-delay: 0.4s; }
        .delay-5 { animation-delay: 0.5s; }
        
        /* ================================================================ */
        /* NAVBAR */
        /* ================================================================ */
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            box-shadow: 0 2px 30px rgba(0, 0, 0, 0.04);
            transition: var(--transition);
        }
        
        .navbar.scrolled {
            padding: 12px 40px;
            box-shadow: 0 4px 40px rgba(0, 0, 0, 0.08);
        }
        
        .navbar .logo {
            font-size: 24px;
            font-weight: 800;
            color: var(--dark);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .navbar .logo i {
            color: var(--primary);
            font-size: 28px;
        }
        
        .navbar .logo span {
            color: var(--primary);
        }
        
        .navbar .nav-links {
            display: flex;
            gap: 32px;
            align-items: center;
            list-style: none;
        }
        
        .navbar .nav-links a {
            text-decoration: none;
            color: var(--black);
            font-weight: 500;
            font-size: 15px;
            transition: var(--transition);
            position: relative;
        }
        
        .navbar .nav-links a:hover {
            color: var(--primary);
        }
        
        .navbar .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary);
            transition: var(--transition);
        }
        
        .navbar .nav-links a:hover::after {
            width: 100%;
        }
        
        .btn-nav {
            padding: 10px 28px;
            border-radius: 30px;
            border: none;
            font-weight: 600;
            font-size: 14px;
            transition: var(--transition);
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-nav-primary {
            background: linear-gradient(135deg, var(--primary), #00c853);
            color: white;
            box-shadow: 0 4px 20px rgba(0, 166, 81, 0.3);
        }
        
        .btn-nav-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(0, 166, 81, 0.4);
            color: white;
        }
        
        .btn-nav-outline {
            background: transparent;
            color: var(--dark);
            border: 2px solid #e2e8f0;
        }
        
        .btn-nav-outline:hover {
            border-color: var(--primary);
            color: var(--primary);
        }
        
        /* Mobile Menu Toggle */
        .menu-toggle {
            display: none;
            font-size: 28px;
            cursor: pointer;
            color: var(--dark);
            background: none;
            border: none;
        }
        
        /* ================================================================ */
        /* HERO SECTION */
        /* ================================================================ */
        .hero {
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 120px 40px 60px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e8f5e9 100%);
            position: relative;
            overflow: hidden;
        }
        
        .hero::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(0, 166, 81, 0.06) 0%, transparent 70%);
            border-radius: 50%;
        }
        
        .hero::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -10%;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(108, 92, 231, 0.05) 0%, transparent 70%);
            border-radius: 50%;
        }
        
        .hero .container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
            position: relative;
            z-index: 1;
        }
        
        .hero .content h1 {
            font-size: 52px;
            font-weight: 900;
            line-height: 1.1;
            margin-bottom: 20px;
        }
        
        .hero .content h1 .highlight {
            background: linear-gradient(135deg, var(--primary), #00c853, var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            background-size: 300% 300%;
            animation: gradientMove 4s ease infinite;
        }
        
        .hero .content p {
            font-size: 18px;
            color: var(--gray);
            line-height: 1.8;
            margin-bottom: 30px;
            max-width: 480px;
        }
        
        .hero .content .cta-buttons {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
        }
        
        .btn-primary {
            padding: 14px 36px;
            border-radius: 30px;
            border: none;
            font-weight: 700;
            font-size: 16px;
            transition: var(--transition);
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        .btn-primary-filled {
            background: linear-gradient(135deg, var(--primary), #00c853);
            color: white;
            box-shadow: 0 4px 25px rgba(0, 166, 81, 0.35);
        }
        
        .btn-primary-filled:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 40px rgba(0, 166, 81, 0.45);
            color: white;
        }
        
        .btn-primary-outline {
            background: transparent;
            color: var(--dark);
            border: 2px solid #e2e8f0;
        }
        
        .btn-primary-outline:hover {
            border-color: var(--primary);
            color: var(--primary);
            transform: translateY(-4px);
        }
        
        .hero .stats {
            display: flex;
            gap: 40px;
            margin-top: 40px;
        }
        
        .hero .stats .stat-item h3 {
            font-size: 28px;
            font-weight: 800;
            color: var(--dark);
        }
        
        .hero .stats .stat-item h3 .stat-number {
            background: linear-gradient(135deg, var(--primary), #00c853);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .hero .stats .stat-item p {
            font-size: 14px;
            color: var(--gray);
            margin-bottom: 0;
        }
        
        .hero .illustration {
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
        }
        
        .hero .illustration .phone-mockup {
            width: 380px;
            height: 700px;
            background: var(--dark);
            border-radius: 40px;
            padding: 16px;
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.15);
            position: relative;
            animation: float 4s ease-in-out infinite;
        }
        
        .hero .illustration .phone-mockup .screen {
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #1a1a2e, #2d2d44);
            border-radius: 28px;
            padding: 20px 16px;
            overflow: hidden;
            position: relative;
        }
        
        .hero .illustration .phone-mockup .screen .status-bar {
            display: flex;
            justify-content: space-between;
            color: rgba(255, 255, 255, 0.6);
            font-size: 12px;
            font-weight: 500;
            margin-bottom: 16px;
        }
        
        .hero .illustration .phone-mockup .screen .greeting {
            color: white;
            font-size: 18px;
            font-weight: 700;
        }
        
        .hero .illustration .phone-mockup .screen .greeting span {
            color: var(--primary);
        }
        
        .hero .illustration .phone-mockup .screen .saldo-card-mock {
            background: linear-gradient(135deg, var(--primary), #00c853);
            border-radius: 16px;
            padding: 16px;
            margin: 12px 0;
            color: white;
        }
        
        .hero .illustration .phone-mockup .screen .saldo-card-mock .label {
            font-size: 12px;
            opacity: 0.8;
        }
        
        .hero .illustration .phone-mockup .screen .saldo-card-mock .amount {
            font-size: 24px;
            font-weight: 800;
        }
        
        .hero .illustration .phone-mockup .screen .quick-actions-mock {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin: 12px 0;
        }
        
        .hero .illustration .phone-mockup .screen .quick-actions-mock .action {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 10px 4px;
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 10px;
        }
        
        .hero .illustration .phone-mockup .screen .quick-actions-mock .action i {
            font-size: 20px;
            display: block;
            margin-bottom: 4px;
        }
        
        .hero .illustration .phone-mockup .screen .progress-mock {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 12px;
            margin: 12px 0;
        }
        
        .hero .illustration .phone-mockup .screen .progress-mock .bar {
            height: 8px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            overflow: hidden;
            margin-top: 6px;
        }
        
        .hero .illustration .phone-mockup .screen .progress-mock .bar .fill {
            height: 100%;
            width: 65%;
            background: linear-gradient(90deg, var(--primary), #00c853);
            border-radius: 10px;
        }
        
        .floating-badge {
            position: absolute;
            background: white;
            border-radius: 16px;
            padding: 12px 18px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 600;
            font-size: 14px;
            animation: float 3s ease-in-out infinite;
        }
        
        .floating-badge-1 {
            top: 5%;
            right: -15%;
            animation-delay: 0s;
        }
        
        .floating-badge-2 {
            bottom: 20%;
            left: -20%;
            animation-delay: 1s;
        }
        
        .floating-badge i {
            font-size: 24px;
        }
        
        .floating-badge .badge-green i { color: var(--primary); }
        .floating-badge .badge-purple i { color: var(--secondary); }
        
        /* ================================================================ */
        /* FEATURES SECTION */
        /* ================================================================ */
        .features {
            padding: 80px 40px;
            background: var(--white);
        }
        
        .features .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .section-header {
            text-align: center;
            margin-bottom: 60px;
        }
        
        .section-header h2 {
            font-size: 40px;
            font-weight: 800;
            margin-bottom: 12px;
        }
        
        .section-header h2 span {
            background: linear-gradient(135deg, var(--primary), #00c853);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .section-header p {
            font-size: 18px;
            color: var(--gray);
            max-width: 600px;
            margin: 0 auto;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
        }
        
        .feature-card {
            background: var(--white);
            border-radius: var(--radius);
            padding: 32px 28px;
            box-shadow: var(--shadow);
            transition: var(--transition);
            border: 1px solid rgba(0, 0, 0, 0.04);
            position: relative;
            overflow: hidden;
            cursor: default;
        }
        
        .feature-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-hover);
        }
        
        .feature-card .icon-wrapper {
            width: 64px;
            height: 64px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            margin-bottom: 20px;
        }
        
        .feature-card .icon-wrapper.green {
            background: var(--primary-light);
            color: var(--primary);
        }
        
        .feature-card .icon-wrapper.purple {
            background: #f0edff;
            color: var(--secondary);
        }
        
        .feature-card .icon-wrapper.pink {
            background: #fde8f0;
            color: var(--accent-1);
        }
        
        .feature-card .icon-wrapper.blue {
            background: #e8f4fd;
            color: var(--accent-3);
        }
        
        .feature-card .icon-wrapper.orange {
            background: #fef8e7;
            color: var(--accent-2);
        }
        
        .feature-card .icon-wrapper.red {
            background: #fde8e8;
            color: #e74c3c;
        }
        
        .feature-card h3 {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .feature-card p {
            color: var(--gray);
            font-size: 15px;
            line-height: 1.7;
        }
        
        .feature-card .feature-number {
            position: absolute;
            top: 16px;
            right: 20px;
            font-size: 48px;
            font-weight: 900;
            color: rgba(0, 0, 0, 0.04);
            line-height: 1;
        }
        
        /* ================================================================ */
        /* STATS SECTION */
        /* ================================================================ */
        .stats-section {
            padding: 80px 40px;
            background: linear-gradient(135deg, var(--dark), #2d2d44);
            color: white;
        }
        
        .stats-section .container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 40px;
            text-align: center;
        }
        
        .stats-section .stat-item h3 {
            font-size: 48px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--primary), #00c853);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .stats-section .stat-item p {
            font-size: 16px;
            opacity: 0.7;
            margin-top: 4px;
        }
        
        /* ================================================================ */
        /* CTA SECTION */
        /* ================================================================ */
        .cta-section {
            padding: 80px 40px;
            background: linear-gradient(135deg, var(--primary), #00c853);
            color: white;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .cta-section::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
        }
        
        .cta-section .container {
            max-width: 700px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }
        
        .cta-section h2 {
            font-size: 40px;
            font-weight: 800;
            margin-bottom: 16px;
        }
        
        .cta-section p {
            font-size: 18px;
            opacity: 0.85;
            margin-bottom: 30px;
        }
        
        .cta-section .btn-white {
            padding: 16px 48px;
            border-radius: 30px;
            border: none;
            background: white;
            color: var(--primary);
            font-weight: 700;
            font-size: 18px;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 12px;
        }
        
        .cta-section .btn-white:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
        }
        
        /* ================================================================ */
        /* FOOTER */
        /* ================================================================ */
        .footer {
            padding: 40px 40px 20px;
            background: var(--dark);
            color: rgba(255, 255, 255, 0.6);
        }
        
        .footer .container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .footer .logo {
            font-size: 20px;
            font-weight: 800;
            color: white;
        }
        
        .footer .logo i {
            color: var(--primary);
        }
        
        .footer .links {
            display: flex;
            gap: 24px;
        }
        
        .footer .links a {
            color: rgba(255, 255, 255, 0.6);
            text-decoration: none;
            transition: var(--transition);
            font-size: 14px;
        }
        
        .footer .links a:hover {
            color: white;
        }
        
        .footer .social {
            display: flex;
            gap: 16px;
        }
        
        .footer .social a {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.05);
            display: flex;
            align-items: center;
            justify-content: center;
            color: rgba(255, 255, 255, 0.6);
            text-decoration: none;
            transition: var(--transition);
        }
        
        .footer .social a:hover {
            background: var(--primary);
            color: white;
        }
        
        .footer .bottom {
            max-width: 1200px;
            margin: 20px auto 0;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            text-align: center;
            font-size: 13px;
        }
        
        /* ================================================================ */
        /* RESPONSIVE */
        /* ================================================================ */
        @media (max-width: 1024px) {
            .hero .container {
                grid-template-columns: 1fr;
                text-align: center;
            }
            
            .hero .content p {
                margin: 0 auto 30px;
            }
            
            .hero .content .cta-buttons {
                justify-content: center;
            }
            
            .hero .stats {
                justify-content: center;
            }
            
            .hero .illustration .phone-mockup {
                width: 300px;
                height: 560px;
            }
            
            .floating-badge {
                display: none;
            }
            
            .features-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .stats-section .container {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .navbar .nav-links {
                display: none;
            }
            
            .navbar .nav-links.open {
                display: flex;
                flex-direction: column;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: white;
                padding: 20px 40px;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
                gap: 16px;
            }
            
            .menu-toggle {
                display: block;
            }
            
            .hero .content h1 {
                font-size: 36px;
            }
        }
        
        @media (max-width: 768px) {
            .navbar {
                padding: 12px 20px;
            }
            
            .hero {
                padding: 100px 20px 40px;
            }
            
            .hero .content h1 {
                font-size: 28px;
            }
            
            .hero .stats {
                flex-wrap: wrap;
                gap: 20px;
            }
            
            .features-grid {
                grid-template-columns: 1fr;
            }
            
            .section-header h2 {
                font-size: 28px;
            }
            
            .stats-section .container {
                grid-template-columns: 1fr 1fr;
                gap: 20px;
            }
            
            .stats-section .stat-item h3 {
                font-size: 32px;
            }
            
            .cta-section h2 {
                font-size: 28px;
            }
            
            .footer .container {
                flex-direction: column;
                text-align: center;
            }
        }
        
        @media (max-width: 480px) {
            .hero .illustration .phone-mockup {
                width: 240px;
                height: 440px;
                padding: 10px;
            }
            
            .hero .illustration .phone-mockup .screen {
                border-radius: 18px;
                padding: 12px;
            }
            
            .hero .illustration .phone-mockup .screen .saldo-card-mock .amount {
                font-size: 18px;
            }
            
            .btn-primary {
                font-size: 14px;
                padding: 12px 24px;
            }
            
            .hero .content h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>

<!-- ================================================================ -->
<!-- NAVBAR -->
<!-- ================================================================ -->
<nav class="navbar" id="navbar">
    <a href="#" class="logo">
        <i class="fas fa-wallet"></i> Yuk<span>Nabung</span>
    </a>
    
    <ul class="nav-links" id="navLinks">
        <li><a href="#features">Fitur</a></li>
        <li><a href="#stats">Statistik</a></li>
        <li><a href="#cta">Mulai</a></li>
        <li>
            <a href="<?= site_url('auth/login') ?>" class="btn-nav btn-nav-outline">
                Login
            </a>
        </li>
        <li>
            <a href="<?= site_url('auth/register') ?>" class="btn-nav btn-nav-primary text-white">
                <i class="fas fa-user-plus"></i> Daftar
            </a>
        </li>
    </ul>
    
    <button class="menu-toggle" id="menuToggle" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
    </button>
</nav>

<!-- ================================================================ -->
<!-- HERO SECTION -->
<!-- ================================================================ -->
<section class="hero" id="hero">
    <div class="container">
        <div class="content">
            <h1 class="animate-fadeUp">
                Kelola Keuangan & <br>
                <span class="highlight">Tabungan</span> Jadi Mudah
            </h1>
            <p class="animate-fadeUp delay-1">
                Aplikasi pencatatan keuangan dan tabungan untuk kamu dan pasangan. 
                Pantau pemasukan, pengeluaran, dan target tabungan dalam satu aplikasi.
            </p>
            <div class="cta-buttons animate-fadeUp delay-2">
                <a href="<?= site_url('auth/register') ?>" class="btn-primary btn-primary-filled">
                    <i class="fas fa-rocket"></i> Mulai Sekarang
                </a>
                <a href="#features" class="btn-primary btn-primary-outline">
                    <i class="fas fa-play-circle"></i> Lihat Fitur
                </a>
            </div>
            <div class="stats animate-fadeUp delay-3">
                <div class="stat-item">
                    <h3><span class="stat-number">10K+</span></h3>
                    <p>Transaksi Dicatat</p>
                </div>
                <div class="stat-item">
                    <h3><span class="stat-number">500+</span></h3>
                    <p>User Aktif</p>
                </div>
                <div class="stat-item">
                    <h3><span class="stat-number">Rp 1M+</span></h3>
                    <p>Tabungan Terkumpul</p>
                </div>
            </div>
        </div>
        
        <div class="illustration animate-fadeRight">
            <div class="phone-mockup">
                <div class="screen">
                    <div class="status-bar">
                        <span>9:41</span>
                        <span><i class="fas fa-wifi"></i> <i class="fas fa-battery-full"></i></span>
                    </div>
                    <div class="greeting">Hai, <span>User</span>! 👋</div>
                    <div class="saldo-card-mock">
                        <div class="label">💰 Total Saldo</div>
                        <div class="amount">Rp 2.000.000</div>
                    </div>
                    <div class="quick-actions-mock">
                        <div class="action"><i class="fas fa-arrow-down"></i> Masuk</div>
                        <div class="action"><i class="fas fa-arrow-up"></i> Keluar</div>
                        <div class="action"><i class="fas fa-piggy-bank"></i> Nabung</div>
                        <div class="action"><i class="fas fa-chart-line"></i> Laporan</div>
                    </div>
                    <div class="progress-mock">
                        <div style="display:flex;justify-content:space-between;font-size:12px;color:rgba(255,255,255,0.7);">
                            <span>📈 Progress Tabungan</span>
                            <span>65%</span>
                        </div>
                        <div class="bar">
                            <div class="fill" style="width:65%;"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Floating Badges -->
            <div class="floating-badge floating-badge-1">
                <span class="badge-green"><i class="fas fa-check-circle"></i></span>
                <div>
                    <div style="font-weight:700;font-size:16px;">Target Tercapai!</div>
                    <div style="font-weight:400;font-size:12px;color:var(--gray);">Bulan ini berhasil</div>
                </div>
            </div>
            
            <div class="floating-badge floating-badge-2">
                <span class="badge-purple"><i class="fas fa-trophy"></i></span>
                <div>
                    <div style="font-weight:700;font-size:16px;">Rank #1</div>
                    <div style="font-weight:400;font-size:12px;color:var(--gray);">Leaderboard bulan ini</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ================================================================ -->
<!-- FEATURES SECTION -->
<!-- ================================================================ -->
<section class="features" id="features">
    <div class="container">
        <div class="section-header">
            <h2>Fitur <span>Lengkap</span> untuk Keuanganmu</h2>
            <p>Semua yang kamu butuhkan untuk mengelola keuangan dan tabungan dengan mudah</p>
        </div>
        
        <div class="features-grid">
            <div class="feature-card animate-fadeUp delay-1">
                <div class="feature-number">01</div>
                <div class="icon-wrapper green">
                    <i class="fas fa-wallet"></i>
                </div>
                <h3>Catat Transaksi</h3>
                <p>Catat pemasukan dan pengeluaran dengan mudah. Dilengkapi filter dan laporan lengkap.</p>
            </div>
            
            <div class="feature-card animate-fadeUp delay-2">
                <div class="feature-number">02</div>
                <div class="icon-wrapper purple">
                    <i class="fas fa-piggy-bank"></i>
                </div>
                <h3>Target Tabungan</h3>
                <p>Set target tabungan bulanan dan pantau progress secara real-time.</p>
            </div>
            
            <div class="feature-card animate-fadeUp delay-3">
                <div class="feature-number">03</div>
                <div class="icon-wrapper pink">
                    <i class="fas fa-users"></i>
                </div>
                <h3>Multi User</h3>
                <p>Kelola keuangan bersama pasangan atau tim dengan role admin dan user.</p>
            </div>
            
            <div class="feature-card animate-fadeUp delay-2">
                <div class="feature-number">04</div>
                <div class="icon-wrapper blue">
                    <i class="fas fa-trophy"></i>
                </div>
                <h3>Leaderboard</h3>
                <p>Lihat progress tabungan user lain dan dapatkan motivasi untuk menabung lebih banyak.</p>
            </div>
            
            <div class="feature-card animate-fadeUp delay-3">
                <div class="feature-number">05</div>
                <div class="icon-wrapper orange">
                    <i class="fas fa-chart-bar"></i>
                </div>
                <h3>Laporan & Grafik</h3>
                <p>Visualisasi data keuangan dengan grafik yang menarik dan laporan PDF/Excel.</p>
            </div>
            
            <div class="feature-card animate-fadeUp delay-4">
                <div class="feature-number">06</div>
                <div class="icon-wrapper red">
                    <i class="fas fa-bell"></i>
                </div>
                <h3>Notifikasi</h3>
                <p>Dapatkan notifikasi progress tabungan dan pengingat target setiap bulan.</p>
            </div>
        </div>
    </div>
</section>

<!-- ================================================================ -->
<!-- STATS SECTION -->
<!-- ================================================================ -->
<section class="stats-section" id="stats">
    <div class="container">
        <div class="stat-item animate-fadeUp delay-1">
            <h3>10K+</h3>
            <p>Transaksi Dicatat</p>
        </div>
        <div class="stat-item animate-fadeUp delay-2">
            <h3>500+</h3>
            <p>User Aktif</p>
        </div>
        <div class="stat-item animate-fadeUp delay-3">
            <h3>Rp 1M+</h3>
            <p>Tabungan Terkumpul</p>
        </div>
        <div class="stat-item animate-fadeUp delay-4">
            <h3>99%</h3>
            <p>Tingkat Kepuasan</p>
        </div>
    </div>
</section>

<!-- ================================================================ -->
<!-- CTA SECTION -->
<!-- ================================================================ -->
<section class="cta-section" id="cta">
    <div class="container">
        <h2 class="animate-fadeUp">Siap Mengelola Keuanganmu?</h2>
        <p class="animate-fadeUp delay-1">
            Bergabunglah sekarang dan mulai catat keuangan serta tabungan dengan mudah.
            Gratis dan tanpa ribet!
        </p>
        <a href="<?= site_url('auth/register') ?>" class="btn-white animate-fadeUp delay-2">
            <i class="fas fa-rocket"></i> Mulai Sekarang
        </a>
    </div>
</section>

<!-- ================================================================ -->
<!-- FOOTER -->
<!-- ================================================================ -->
<footer class="footer">
    <div class="container">
        <div class="logo">
            <i class="fas fa-wallet"></i> YukNabung
        </div>
        <div class="links">
            <a href="#features">Fitur</a>
            <a href="#stats">Statistik</a>
            <a href="<?= site_url('auth/login') ?>">Login</a>
            <a href="<?= site_url('auth/register') ?>">Daftar</a>
        </div>
        <div class="social">
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
            <a href="#"><i class="fab fa-tiktok"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
    </div>
    <div class="bottom">
        &copy; <?= date('Y') ?> YukNabung. All rights reserved.
    </div>
</footer>

<!-- ================================================================ -->
<!-- SCRIPTS -->
<!-- ================================================================ -->
<script>
    // ================================================================
    // NAVBAR SCROLL EFFECT
    // ================================================================
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    // ================================================================
    // MOBILE MENU TOGGLE
    // ================================================================
    const menuToggle = document.getElementById('menuToggle');
    const navLinks = document.getElementById('navLinks');
    
    menuToggle.addEventListener('click', function() {
        navLinks.classList.toggle('open');
        this.innerHTML = navLinks.classList.contains('open') 
            ? '<i class="fas fa-times"></i>' 
            : '<i class="fas fa-bars"></i>';
    });
    
    // ================================================================
    // CLOSE MOBILE MENU ON LINK CLICK
    // ================================================================
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', function() {
            navLinks.classList.remove('open');
            menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
        });
    });
    
    // ================================================================
    // SMOOTH SCROLL
    // ================================================================
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
    
    // ================================================================
    // SCROLL REVEAL ANIMATION (Intersection Observer)
    // ================================================================
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    document.querySelectorAll('.animate-fadeUp, .animate-fadeLeft, .animate-fadeRight').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(40px)';
        el.style.transition = 'all 0.8s ease';
        observer.observe(el);
    });
    
    // ================================================================
    // COUNTER ANIMATION
    // ================================================================
    function animateCounter(element, target, suffix = '') {
        let current = 0;
        const increment = target / 60;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            element.textContent = Math.floor(current) + suffix;
        }, 25);
    }
    
    // ================================================================
    // PARALLAX EFFECT ON HERO
    // ================================================================
    document.addEventListener('mousemove', function(e) {
        const phone = document.querySelector('.phone-mockup');
        if (phone && window.innerWidth > 768) {
            const x = (e.clientX / window.innerWidth - 0.5) * 10;
            const y = (e.clientY / window.innerHeight - 0.5) * 10;
            phone.style.transform = `rotateY(${x}deg) rotateX(${-y}deg)`;
        }
    });
</script>

</body>
</html>
