<!DOCTYPE html>
<html>
<head>
    <title>Laporan Keuangan</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .header { text-align: center; margin-bottom: 20px; }
        .header h1 { margin: 0; }
        .header p { margin: 0; color: #666; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        table th, table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        table th { background: #1a56db; color: white; }
        .summary { margin: 10px 0; }
        .summary .item { display: inline-block; width: 30%; padding: 10px; background: #f4f4f4; margin: 5px; text-align: center; }
        .footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
        .text-success { color: #28a745; }
        .text-danger { color: #dc3545; }
        .text-primary { color: #1a56db; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Laporan Keuangan</h1>
        <p><?= $user->username ?> - Bulan <?= $month_name ?> <?= $year ?></p>
    </div>
    
    <div class="summary">
        <div class="item">
            <strong>Total Pemasukan</strong><br>
            <span class="text-success">Rp <?= number_format($summary->total_income ?? 0, 0, ',', '.') ?></span>
        </div>
        <div class="item">
            <strong>Total Pengeluaran</strong><br>
            <span class="text-danger">Rp <?= number_format($summary->total_expense ?? 0, 0, ',', '.') ?></span>
        </div>
        <div class="item">
            <strong>Saldo</strong><br>
            <span class="text-primary">Rp <?= number_format($summary->balance ?? 0, 0, ',', '.') ?></span>
        </div>
    </div>
    
    <h3>Daftar Transaksi</h3>
    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Jenis</th>
                <th>Kategori</th>
                <th>Jumlah</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($transactions)): ?>
            <tr><td colspan="5" style="text-align: center;">Tidak ada transaksi</td></tr>
            <?php else: ?>
            <?php foreach ($transactions as $trx): ?>
            <tr>
                <td><?= date('d-m-Y', strtotime($trx->transaction_date)) ?></td>
                <td><?= $trx->type == 'income' ? 'Pemasukan' : 'Pengeluaran' ?></td>
                <td><?= $trx->category ?></td>
                <td>Rp <?= number_format($trx->amount, 0, ',', '.') ?></td>
                <td><?= $trx->description ?? '-' ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    
    <h3>Tabungan</h3>
    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Jumlah Setoran</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($savings)): ?>
            <tr><td colspan="3" style="text-align: center;">Tidak ada setoran tabungan</td></tr>
            <?php else: ?>
            <?php foreach ($savings as $saving): ?>
            <tr>
                <td><?= date('d-m-Y', strtotime($saving->deposit_date)) ?></td>
                <td>Rp <?= number_format($saving->amount, 0, ',', '.') ?></td>
                <td><?= $saving->description ?? '-' ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            <tr style="font-weight: bold; background: #f4f4f4;">
                <td colspan="1">Total Tabungan</td>
                <td>Rp <?= number_format($total_savings, 0, ',', '.') ?></td>
                <td>Target: Rp <?= number_format($target->target_amount ?? 0, 0, ',', '.') ?></td>
            </tr>
        </tbody>
    </table>
    
    <div class="footer">
        Dicetak pada: <?= date('d-m-Y H:i:s') ?>
    </div>
</body>
</html>
