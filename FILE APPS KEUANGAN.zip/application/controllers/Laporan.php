<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model(['transaction_model', 'savings_model', 'user_model']);
        $this->load->library('template');
        
        if (!$this->session->userdata('logged_in')) {
            redirect('auth/login');
        }
    }
    
    public function index() {
        $this->template
            ->page_title('Laporan')
            ->load('laporan/index');
			->hide_header() //ini breadchumb diatas 
    }
    
    public function pdf() {
        $user_id = $this->session->userdata('user_id');
        $month = $this->input->get('month') ?? date('m');
        $year = $this->input->get('year') ?? date('Y');
        
        // Data transaksi
        $transactions = $this->transaction_model->get_by_user_month($user_id, $month, $year);
        $summary = $this->transaction_model->get_summary($user_id, $month, $year);
        
        // Data tabungan
        $savings = $this->savings_model->get_by_user_month($user_id, $month, $year);
        $total_savings = $this->savings_model->get_total_by_user_month($user_id, $month, $year);
        $target = $this->savings_target_model->get_or_create($user_id, $month, $year);
        
        $data = [
            'transactions' => $transactions,
            'summary' => $summary,
            'savings' => $savings,
            'total_savings' => $total_savings,
            'target' => $target,
            'month' => $month,
            'year' => $year,
            'user' => $this->user_model->get_row(['id' => $user_id]),
            'month_name' => date('F', mktime(0, 0, 0, $month, 1))
        ];
        
        // Load library Dompdf
        require_once APPPATH . 'libraries/dompdf/autoload.inc.php';
        $dompdf = new Dompdf\Dompdf();
        
        $html = $this->load->view('laporan/pdf', $data, TRUE);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $dompdf->stream("Laporan_Keuangan_" . date('Y-m-d') . ".pdf", array("Attachment" => 0));
    }
}
