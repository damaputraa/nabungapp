<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model(['user_model', 'savings_target_model', 'transaction_model']);
        $this->load->library(['form_validation', 'template']);
        
        if (!$this->session->userdata('logged_in') || $this->session->userdata('role') != 'admin') {
            redirect('auth/login');
        }
    }
    
    public function users() {
        $data['users'] = $this->user_model->get_all();
        
        $this->template
            ->page_title('Kelola User')
            ->plugins(['datatables'])
			->hide_header() //ini breadchumb diatas 
            ->load('admin/users', $data);
    }
    
    // ========== TAMBAH USER ==========
    public function add_user() {
        $this->form_validation->set_rules('username', 'Username', 'required|is_unique[users.username]');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('role', 'Role', 'required|in_list[admin,user]');
        
        if ($this->form_validation->run() == FALSE) {
            $this->template
                ->page_title('Tambah User')
                ->load('admin/add_user');
        } else {
            $data = [
                'username' => $this->input->post('username'),
                'email' => $this->input->post('email'),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'role' => $this->input->post('role')
            ];
            
            $this->user_model->insert($data);
            $this->session->set_flashdata('success', 'User berhasil ditambahkan!');
            redirect('admin/users');
        }
    }
    
    // ========== EDIT USER ==========
    public function edit_user($id) {
        $user = $this->user_model->get_row(['id' => $id]);
        
        if (!$user) {
            show_404();
        }
        
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('role', 'Role', 'required|in_list[admin,user]');
        $this->form_validation->set_rules('password', 'Password', 'min_length[6]');
        
        if ($this->form_validation->run() == FALSE) {
            $data['user'] = $user;
            $this->template
                ->page_title('Edit User')
                ->load('admin/edit_user', $data);
        } else {
            $update_data = [
                'username' => $this->input->post('username'),
                'email' => $this->input->post('email'),
                'role' => $this->input->post('role')
            ];
            
            // Jika password diisi, update password
            $password = $this->input->post('password');
            if (!empty($password)) {
                $update_data['password'] = password_hash($password, PASSWORD_DEFAULT);
            }
            
            $this->user_model->update(['id' => $id], $update_data);
            $this->session->set_flashdata('success', 'User berhasil diupdate!');
            redirect('admin/users');
        }
    }
    
    // ========== HAPUS USER ==========
    public function delete_user($id) {
        // Cegah menghapus diri sendiri
        if ($id == $this->session->userdata('user_id')) {
            $this->session->set_flashdata('error', 'Anda tidak bisa menghapus akun sendiri!');
            redirect('admin/users');
        }
        
        $this->user_model->delete(['id' => $id]);
        $this->session->set_flashdata('success', 'User berhasil dihapus!');
        redirect('admin/users');
    }
    
    // ========== TARGET TABUNGAN ==========
    public function targets() {
        $users = $this->user_model->get_all();
        $data['users'] = $users;
        
        $current_month = date('m');
        $current_year = date('Y');
        
        foreach ($users as $user) {
            $user->target = $this->savings_target_model->get_by_user_month(
                $user->id, $current_month, $current_year
            );
            $user->saving = $this->transaction_model->get_summary(
                $user->id, $current_month, $current_year
            );
        }
        
        $this->template
            ->page_title('Target Tabungan')
            ->load('admin/targets', $data);
    }
    
    public function set_target() {
        $this->form_validation->set_rules('user_id', 'User', 'required');
        $this->form_validation->set_rules('target_amount', 'Target', 'required|numeric');
        
        if ($this->form_validation->run() == FALSE) {
            redirect('admin/targets');
        } else {
            $user_id = $this->input->post('user_id');
            $month_year = date('Y-m');
            
            $existing = $this->savings_target_model->get_by_user_month(
                $user_id, date('m'), date('Y')
            );
            
            $data = [
                'user_id' => $user_id,
                'month_year' => $month_year,
                'target_amount' => $this->input->post('target_amount')
            ];
            
            if ($existing) {
                $this->savings_target_model->update(['id' => $existing->id], $data);
            } else {
                $this->savings_target_model->insert($data);
            }
            
            $this->session->set_flashdata('success', 'Target tabungan berhasil diset!');
            redirect('admin/targets');
        }
    }
}
