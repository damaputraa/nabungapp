<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model(['transaction_model', 'savings_target_model', 'savings_model', 'user_model']);
        $this->load->library('template');
        
        if (!$this->session->userdata('logged_in')) {
            redirect('auth/login');
        }
    }
    
    public function index() {
        $user_id = $this->session->userdata('user_id');
        $current_month = date('m');
        $current_year = date('Y');
        $role = $this->session->userdata('role');
        
        // ========== DATA TRANSAKSI ==========
        $summary = $this->transaction_model->get_summary($user_id, $current_month, $current_year);
        $total_income = (float) $this->transaction_model->get_income_by_user($user_id);
        $total_expense = (float) $this->transaction_model->get_expense_by_user($user_id);
        
        // ========== DATA TABUNGAN ==========
        $savings_target = $this->savings_target_model->get_or_create($user_id, $current_month, $current_year);
        $savings_total_deposit = (float) $this->savings_model->get_total_by_user_month($user_id, $current_month, $current_year);
        
        // ========== DATA TRANSAKSI TERAKHIR (untuk user) ==========
        $transactions = $this->transaction_model->get_by_user($user_id);
        
        // ========== DATA SEMUA USER (admin) ==========
        $all_users_savings = [];
        if ($role == 'admin') {
            $all_users = $this->user_model->get_all();
            foreach ($all_users as $user) {
                $target = $this->savings_target_model->get_or_create($user->id, $current_month, $current_year);
                $total_deposit = (float) $this->savings_model->get_total_by_user_month($user->id, $current_month, $current_year);
                
                $all_users_savings[] = (object) [
                    'username' => $user->username,
                    'target_amount' => (float) ($target->target_amount ?? 0),
                    'total_deposit' => $total_deposit
                ];
            }
        }
        
        // ========== NOTIFIKASI ==========
        $this->load->model('notification_model');
        $notification = $this->notification_model->check_savings_progress(
            $user_id, 
            $savings_total_deposit, 
            $savings_target->target_amount ?? 1
        );
        
        // ========== SIAPKAN DATA UNTUK VIEW ==========
        $data = [
            'title' => 'Dashboard',
            'summary' => $summary,
            'total_income' => $total_income,
            'total_expense' => $total_expense,
            'balance' => $total_income - $total_expense,
            'current_month' => date('F Y'),
            // Data tabungan
            'savings_target' => $savings_target,
            'savings_total_deposit' => $savings_total_deposit,
            // Data semua user
            'all_users_savings' => $all_users_savings,
            // Notifikasi
            'notification' => $notification,
            // Transaksi terakhir (untuk user)
            'transactions' => $transactions
        ];
        
        // ========== PILIH TAMPILAN BERDASARKAN ROLE ==========
        if ($role == 'user') {
            // Tampilan mobile ala Gojek untuk user
            $this->template
                ->page_title('Dashboard')
                ->hide_header()
                ->load('dashboard/user_dashboard', $data);
        } else {
            // Tampilan admin (seperti sebelumnya)
            $this->template
                ->page_title('Dashboard Keuangan')
                ->hide_header()
                ->plugins(['chartjs'])
                ->page_js(['assets/js/dashboard.js'])
                ->load('dashboard/index', $data);
        }
    }
}
