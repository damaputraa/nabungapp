<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
*/

// ================================================================
// DEFAULT ROUTE - LANDING PAGE
// ================================================================
$route['default_controller'] = 'landing';

// ================================================================
// AUTH ROUTES
// ================================================================
$route['auth/login'] = 'auth/login';
$route['auth/register'] = 'auth/register';
$route['auth/logout'] = 'auth/logout';

// ================================================================
// DASHBOARD ROUTES
// ================================================================
$route['dashboard'] = 'dashboard/index';

// ================================================================
// TRANSACTION ROUTES
// ================================================================
$route['transactions'] = 'transactions/index';
$route['transactions/add'] = 'transactions/add';
$route['transactions/edit/(:num)'] = 'transactions/edit/$1';
$route['transactions/delete/(:num)'] = 'transactions/delete/$1';

// ================================================================
// SAVINGS ROUTES
// ================================================================
$route['savings'] = 'savings/index';
$route['savings/add'] = 'savings/add';
$route['savings/delete/(:num)'] = 'savings/delete/$1';
$route['savings/leaderboard'] = 'savings/leaderboard';
$route['savings/view_user/(:num)'] = 'savings/view_user/$1';

// ================================================================
// ADMIN ROUTES
// ================================================================
$route['admin/users'] = 'admin/users';
$route['admin/add_user'] = 'admin/add_user';
$route['admin/edit_user/(:num)'] = 'admin/edit_user/$1';
$route['admin/delete_user/(:num)'] = 'admin/delete_user/$1';
$route['admin/targets'] = 'admin/targets';
$route['admin/set_target'] = 'admin/set_target';

// ================================================================
// PROFILE ROUTES
// ================================================================
$route['profile'] = 'profile/index';
$route['profile/update_password'] = 'profile/update_password';

// ================================================================
// LAPORAN & EXPORT ROUTES
// ================================================================
$route['laporan'] = 'laporan/index';
$route['laporan/pdf'] = 'laporan/pdf';
$route['export/excel'] = 'export/excel';

// ================================================================
// 404 OVERRIDE
// ================================================================
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
